public abstract class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        if (age < 0) {
            throw new IllegalArgumentException("Возраст не может быть отрицательным: " + age);
        }
        this.name = name;
        this.age = age;
    }

    public String getName() { return this.name; }
    public int getAge() { return this.age; }

    public void setName(String name) { this.name = name; }
    public void setAge(int age) {
        if (age < 0) throw new IllegalArgumentException("Возраст не может быть отрицательным!");
        this.age = age;
    }

    // Абстрактный метод — каждый подкласс реализует по-своему (полиморфизм)
    public abstract String getRole();

    @Override
    public String toString() {
        return "[" + getRole() + "] " + this.name + " (возраст: " + this.age + ")";
    }
}
