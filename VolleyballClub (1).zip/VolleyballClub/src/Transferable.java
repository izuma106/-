// Интерфейс для игроков, которых можно переводить между командами
public interface Transferable {
    void transfer(Team newTeam);
    String getTransferInfo();
}
